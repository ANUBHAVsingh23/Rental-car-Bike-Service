-- Wheelzonrent database setup
-- Import this file in MySQL/phpMyAdmin.

CREATE DATABASE IF NOT EXISTS `booking`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `booking`;

-- Drop old tables to allow clean re-import.
DROP TABLE IF EXISTS `feedback`;
DROP TABLE IF EXISTS `package`;

CREATE TABLE `package` (
  `Id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(100) NOT NULL,
  `Email` VARCHAR(150) NOT NULL,
  `Phone` VARCHAR(20) NOT NULL,
  `Message` TEXT NULL,
  `Subject` VARCHAR(200) NULL,
  `Vehicle` VARCHAR(120) NOT NULL,
  `Amount` VARCHAR(50) NOT NULL,
  `Date` DATE NOT NULL,
  `License` LONGBLOB NOT NULL,
  `CreatedAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  KEY `idx_package_vehicle_date` (`Vehicle`, `Date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `feedback` (
  `Id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Feedback` TEXT NOT NULL,
  `CreatedAt` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional seed data
INSERT INTO `feedback` (`Feedback`) VALUES
('Great service and smooth booking process.');
